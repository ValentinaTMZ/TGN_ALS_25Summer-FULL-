Tutorial
========

If you are new to Optuna or want a general introduction, we highly recommend the below video.

.. raw:: html

    <iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/P6NwZVl8ttc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    <br />
    <br />
    <br />
