.. include:: ./generated/index.rst

.. note::
    The following :mod:`optuna.visualization.matplotlib` module uses Matplotlib as a backend.

.. toctree::
    :maxdepth: 1

    matplotlib/index

.. seealso::
    The :ref:`visualization` tutorial provides use-cases with examples.
