# Contributing

This being the code to replicate a research paper, we will not accept 
contributions. 